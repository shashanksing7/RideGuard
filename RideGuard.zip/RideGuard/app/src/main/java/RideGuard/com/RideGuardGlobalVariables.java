package RideGuard.com;
/*
This class wil store the global static variables
 */
public class RideGuardGlobalVariables {
    /*
    Variables for our Notification Channel.
     */
    public  static  final  String ChannelId="RideChannel";
    public  static  final  String ChannelName="OngoingRideChannel";
    public static boolean Connected=false;
    public static  boolean HelmetWorn=false;
    public  static  int AlcoholLevel=0;
}
