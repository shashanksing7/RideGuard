package RideGuard.com.HospitalListScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import RideGuard.com.R;
/*
This class will be used to load the list of hospital.
 */
public class HospitalListScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_list_screen);
    }
}